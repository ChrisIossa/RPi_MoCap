# import the necessary packages
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import numpy as np
import datetime
import RPi.GPIO as GPIO
 
# initialize the camera and grab a reference to the raw camera capture
camera = PiCamera()
camera.resolution = (320, 240)
camera.framerate = 30
rawCapture = PiRGBArray(camera, size=(320, 240))
current_fps = 0
fps_counter = 0
 
# allow the camera to warmup
time.sleep(2)

def draw_marker_text(image, text_to_draw):
    width, height = image.shape[:2]
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(image, "Markers Found: {0}".format(text_to_draw),  # marker counter text
                (height - 300, 25), font, .75, (0, 255, 0), 2)
def display_fps(image):
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(image, "FPS: {0}".format(current_fps), (25, 25), font, .75, (255,255,0), 2)


def find_markers(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # make image gray scale

    thresh = 130  # threshold value, play around with this value to get optimal detection
    max_value = 255
    th, dst = cv2.threshold(gray, thresh, max_value, cv2.THRESH_BINARY)  # apply filter
    im2, contours, hierarchy = cv2.findContours(dst.copy(),  # Make copy, since findContours() is
                                                cv2.RETR_EXTERNAL,  # destructive
                                                cv2.CHAIN_APPROX_SIMPLE)

    marker_count = 0
    if len(contours) > 0:  # check if at least 1 marker was found
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

            rect = cv2.minAreaRect(cnt)
            box = cv2.boxPoints(rect)
            box = np.int0(box)
            cv2.drawContours(image, [box], 0, (0, 0, 255), 2)
 
# capture frames from the camera
record_video = False
video= None
frames_to_write = []
start_time = datetime.datetime.now()

for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        # increment frames for concurrent FPS
        fps_counter += 1
        current_fps = int(fps_counter / (datetime.datetime.now() - start_time).total_seconds())
        
	# grab the raw NumPy array representing the image, then initialize the timestamp
	# and occupied/unoccupied text
	image = frame.array
	
 
	# #show the frame
        find_markers(image)
        display_fps(image)
	cv2.imshow("Frame", image)
	key = cv2.waitKey(1) & 0xFF

        
        
        # capture video
        if record_video is True:
            video.write(image)
        if key == ord("v"):
            record_video = True
            height, width, layers =image.shape
            video = cv2.VideoWriter('/home/pi/Desktop/NewCamera/test2.avi', cv2.VideoWriter_fourcc(*"MJPG"), 30, (640, 480))
	# if the `q` key was pressed, break from the loop
	if key == ord("b"): 
            video.release()


	# clear the stream in preparation for the next frame
	rawCapture.truncate(0)
           
	# if the `q` key was pressed, break from the loop
	if key == ord("q"):
                break
	# if the `c` key was pressed, take snap
	if key == ord("c"):
		cv2.imwrite('/home/pi/Desktop/NewCamera/test3.jpg', image)

#video.release()
