////////////////////////////////////////////////////////////
Contents:

./07-07-2017/disableLightRing.py
./07-07-2017/enableLightRing.py
./07-07-2017/keyTest.py
./07-07-2017/Marker.py
./07-07-2017/MotionCapture.py
./07-07-2017/NameReplacements.txt
./07-07-2017/Readme.txt
./07-07-2017/RunCamera.py

////////////////////////////////////////////////////////////

Last updated:
07/07/2017

////////////////////////////////////////////////////////////

Team Members: Paul Canada, Orquidia Moreno, George Ventura, Christopher Iossa

////////////////////////////////////////////////////////////

Description:
This is the first official version of the Raspberry Pi Motion Capture and Tracking System, created by the MoCap team as part of SGRI 2017 at Western Connecticut State University.
This project took place from 05/21/2017 to 07/07/2017.

////////////////////////////////////////////////////////////